#ifndef __PROJ_THREE__HPP
#define __PROJ_THREE__HPP


#include <iostream>
#include "MyAVLTree.hpp"

void countWords(std::istream & in, MyAVLTree<std::string, unsigned> & counter);



#endif 