#include "proj0.hpp"
#include <string>

int main()
{
    return 0;
}



